import app from "./index.js";
app.listen(3000, () => {
  console.log("server is listening on 3000");
});
